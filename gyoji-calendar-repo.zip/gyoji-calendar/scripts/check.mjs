// 簡易チェック: node scripts/check.mjs
import { readFileSync } from 'node:fs';

const file = process.argv[2] || 'index.html';
const html = readFileSync(file, 'utf8');
let failed = false;
const fail = (msg) => { console.error('✗ ' + msg); failed = true; };
const ok = (msg) => console.log('✓ ' + msg);

// 1. インラインスクリプトの構文
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
if (!scripts.length) fail('<script> が見つかりません');
for (const s of scripts) {
  try { new Function(s); ok('スクリプトの構文OK'); }
  catch (e) { fail('スクリプトの構文エラー: ' + e.message); }
}

// 2. 管理者情報・履歴が空であること(誤公開の防止)
if (/let ACCOUNTS=\[\];/.test(html)) ok('管理者アカウントは空です');
else fail('ACCOUNTS が空ではありません。パスコードのハッシュを公開しないでください');

if (/let LOG=\[\];/.test(html)) ok('操作履歴は空です');
else fail('LOG が空ではありません。操作履歴(名前)を公開しないでください');

// 3. 予定データに作成者・更新者の記録が残っていないこと
if (/"(cb|ub)":\s*"[^"]+"/.test(html)) fail('予定に作成者/更新者の名前が含まれています');
else ok('作成者・更新者の記録はありません');

process.exit(failed ? 1 : 0);

---
name: 機能の要望
about: こんな機能がほしい、というときに使います
labels: enhancement
---

## どんな場面で困っていますか?

## ほしい機能
